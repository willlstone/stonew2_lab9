Will Stone lab 8:

Everything for this lab went pretty smoothly.  I just hope I exported the databases the way you wanted me to.  All of my commands I entered into the SQL line in phpmyadmin are in the lab8.txt file that I zipped up with this. There is a number corresponding to each piece of code that references what part in the instructions it's solving.